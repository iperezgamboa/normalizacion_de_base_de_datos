CREATE DATABASE biblioteca; 

\c biblioteca;  --para entrar


CREATE TABLE libros(codigo INT PRIMARY KEY,nombre VARCHAR(100) NOT NULL);

CREATE TABLE autores(id SERIAL PRIMARY KEY, nombre VARCHAR(100) NOT NULL);

CREATE TABLE editoriales(id SERIAL PRIMARY KEY, nombre VARCHAR(100) NOT NULL);

CREATE TABLE lectores(id SERIAL PRIMARY KEY, nombre VARCHAR(100) NOT NULL);

CREATE TABLE Autores_libros(libros_cod INT, autor_id INT, FOREIGN KEY(libros_cod) REFERENCES libros(codigo), FOREIGN KEY (autor_id) REFERENCES autores(id)); 

CREATE TABLE Editoriales_libros (libros_cod INT, editorial_id INT, FOREIGN KEY(libros_cod) REFERENCES libros(codigo), FOREIGN KEY (editorial_id) REFERENCES editoriales(id)); 

CREATE TABLE Prestamos (id SERIAL PRIMARY KEY, fecha_devolucion DATE NOT NULL, lector_id INT NOT NULL, libro_cod INT NOT NULL, FOREIGN KEY (lector_id) REFERENCES lectores(id), FOREIGN KEY (libro_cod) REFERENCES libros(codigo)); 


-- cuantos libros tiene cada autor

SELECT COUNT(codigo), lectores.nombre FROM libros INNER JOIN prestamos ON libros.codigo = prestamos.libre_cod INNER JOIN lectores ON prestamos.lector_id = lectores.id GROUP BY lectores.nombre;


-- cuantos libros ha pedido cada lector



-- Que libros no han sido entregados aun y su fecha de entrega 

FROM libros INNER JOIN prestamos on libros.codigo = prestamos.libro_cod



